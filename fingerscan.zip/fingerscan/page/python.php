<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>scan</title>
</head>
<body >

	<?php
		$result = escapeshellcmd("enr.py");
		$output = shell_exec($result);
		echo "$output"."<br>";
	?>
</body>
</html>
