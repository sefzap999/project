<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php
	session_start();
	unset($_SESSION['student_id']);
	session_destroy();
	//header("Location: login_student.php");
	echo "<script>
		alert('ออกจากระบบแล้ว!!');
    	location.href = 'login_student.php';  
	</script>";
	exit;
	?>
</body>
</html>