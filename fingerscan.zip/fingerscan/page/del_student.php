<?php
	ob_start();
	session_start();
	ini_set('display_errors', 1);
  	error_reporting(~0);
  	$strstudentID = null;
  	$submit = null;
  	if(isset($_GET["student_id"]))
  	{
    	$strstudentID = $_GET["student_id"];
  	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>ลบข้อมูล</title>
	<link rel="stylesheet" href="styles.css" />
</head>
<body>
<center>
<form name="frmEdit" method="post">
<?php
	$host = "localhost";
	$username = "root";
	$password = "1234";
	$dbname = "project";
	$conn = mysqli_connect($host,$username,$password,$dbname);
	$conn->set_charset("utf8");
	$cutomersql = "SELECT * FROM login_student WHERE student_id = '".$strstudentID."' ";
	$cutomerquery = mysqli_query($conn,$cutomersql);
	$result =mysqli_fetch_array($cutomerquery,MYSQLI_ASSOC);

?>

		<div class="datastudent"> ยืนยันการลบข้อมูล</div>
		<fieldset>
			<legend>ข้อมูล</legend>
			<table>
				<tr>
					<td align="right">ชื่อ :</td>
					<td><?php echo $result["student_Name"] ;?></td>
				</tr>
				<tr>
					<td align="right">นามสกุล :</td>
					<td><?php echo $result["student_Lastname"] ;?></td>
				</tr>
				<tr>
					<td align="right">เพศ :</td>
					<td><?php echo $result["Gender"] ;?></td>
				</tr>
				<tr>
					<td align="right">วัน-เดือน-ปี เกิด :</td>
					<td><?php echo $result["Birthdate"] ;?></td>
				</tr>
				<tr>
					<td align="right">อายุ :</td>
					<td><?php echo $result["Age"] ;?></td>
				</tr>
				<tr>
					<td align="right">ที่อยู่ :</td>
					<td><?php echo $result["Address"] ;?></td>
				</tr>
				<tr>
					<td align="right">จังหวัด :</td>
					<td><?php echo $result["Province"] ;?></td>
				</tr>
				<tr>
					<td align="right">รหัสไปรษณีย์ :</td>
					<td><?php echo $result["Zipcode"] ;?></td>
				</tr>
				<tr>
					<td align="right">โทรศัพท์ :</td>
					<td><?php echo $result["Telephone"] ;?></td>
				</tr>
				<tr>
					<td align="right">รายละเอียดอื่นๆ :</td>
					<td><?php echo $result["student_Description"];?></td>
				</tr>
			</table>
		</fieldset>
		<br>
		<button type="submit" name="del"  value="">ลบข้อมูล</button>
		<input type="button" name="submit" value="ยกเลิก" onclick="window.location='index_admin.php' ">

<?php
	if(isset($_POST["del"])){
		$delsql = "DELETE FROM login_student WHERE student_id = '".$strstudentID."' ";
  		$query = mysqli_query($conn,$delsql);
    	if($query){
			ob_clean();
			echo "Delete Successfully";
			echo "<meta http-equiv='refresh' content='1;url=index_admin.php'>";
    	}else{
    		ob_clean();
    	  	echo "Delete fail";
			echo "<meta http-equiv='refresh' content='2;url=del_student.php'>";
    	}
	}
    mysqli_close($conn);
?>
	</div>
</form>
</center>
</body>
</html>
