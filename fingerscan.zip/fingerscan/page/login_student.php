<?php
include("loginserv_student.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>ระบบสารสนเทศเพื่องานพัฒนานักศึกษา</title>
	<link rel="stylesheet" href="styles.css" />
</head>
<script type="text/javascript">
	function checklogin(){
		alert("ชื่อผู้ใช้หรือรหัสผ่านที่ไม่ถูกต้อง");
	}
</script>
<body topmargin="5%">
<center>
	<h1>ระบบสารสนเทศเพื่องานพัฒนานักศึกษา</h1>
	<h2>กองพัฒนานักศึกษา  มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา</h2>
	<div id="lnews"><img src="images/banner.jpg" width="800" height="90" border="0" alt=""></div>
	<h2><img src="images/computer.png" width="64" height="64" border="0" alt="" align="absmiddle">นักศึกษากรอกข้อมูลเพื่อเข้าสู่ระบบ</h2>
</center>

<form name="login_student" method="POST" action="">
	<div align="center">
		<fieldset>
			<legend><u><font color="red">ล็อกอิน (Login)</font></u></legend>
			<table>
				<tr height="70px">
					<td colspan="2" align="center"><b>กรุณากรอกรหัสผู้ใช้ (UserName) ด้วย<font color="red">รหัสนักศึกษาของท่าน</font> <br>รหัสผ่าน (Password) ด้วย<font color="red">รหัสบัตรประชาชนของท่าน</font> <br> เพื่อเข้าใช้งานระบบ</b></td>
				</tr>
				<tr>
					<td align="right">
						รหัสผู้ใช้ (UserName) :
					</td>
					<td>
						<input type="text" name="txtusername" class="student">
					</td>
				</tr>
				<tr>
					<td align="right">
						รหัสผ่าน (Password) :
					</td>
					<td>
						<input type="password" name="txtpassword" class="student">
					</td>
				</tr>
			</table>
			<br>
				<input type="submit" name="submit" value="เข้าสู่ระบบ">
				<input type="reset" name="cancel" value="ยกเลิก">
		</fieldset>
	</div>
	
	<p class="date">
		<img src="images/home.png" width="25" height="25" border="0" alt="" align="absmiddle">
		<a href="/fingerscan/index.html">หน้าแรก
	 </p>
	
</form>

<?php
	ini_set('display_errors', 1);
	error_reporting(~0);
	$host = "localhost";
	$username = "root";
	$password = "1234";
	$dbname = "project";
	$conn = mysqli_connect($host,$username,$password,$dbname);
	$conn->set_charset("utf8");
	if(isset($_POST["submit"])){
		$loginsql = "SELECT * FROM login_student WHERE username = '".$_POST["txtusername"]."' AND password = '".$_POST["txtpassword"]."'";
		$loginquery = mysqli_query($conn,$loginsql);
		$result = mysqli_fetch_array($loginquery,MYSQLI_ASSOC);
		if(!$result){
			echo "<script language='JavaScript'>checklogin();</script>";
    		echo "<meta http-equiv='refresh' content='1;url=login_student.php'>";
  		}
  		else{
    		$_SESSION["student_id"] = $result["student_id"];
    		$_SESSION["Name"] = $result["student_Name"];
    		$_SESSION["Lastname"] = $result["student_Lastname"];
    		$_SESSION["number"] = $result["student_number"];
    		$_SESSION["agencies"] = $result["agencies"];
    		$_SESSION["subagencies"] = $result["subagencies"];
    		$_SESSION["Gender"] = $result["Gender"];
    		$_SESSION["Birthdate"] = $result["Birthdate"];
    		$_SESSION["Age"] = $result["Age"];
    		$_SESSION["Address"] = $result["Address"];
    		$_SESSION["Province"] = $result["Province"];
    		$_SESSION["Zipcode"] = $result["Zipcode"];
    		$_SESSION["Telephone"] = $result["Telephone"];
    		$_SESSION["Description"] = $result["student_Description"];
    		//$_SESSION["Username"] = $result["Username"];
    		header("location: index_student.php");
    	}
    }
	mysqli_close($conn);
?>


</body>
</html>
