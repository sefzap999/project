<?php
session_start();
$error='';
if(isset($_POST['submit'])){
 if(empty($_POST['user']) || empty($_POST['pass'])){
 $error = "Username or Password is Invalid";
 }
 else
 {
 // $user and $pass
 $user=$_POST['user'];
 $pass=$_POST['pass'];
 //Connection Database
 $conn = mysqli_connect("localhost", "root", "1234");
 //Selecting Database
 $db = mysqli_select_db($conn, "project");
 //sql query data
 $query = mysqli_query($conn, "SELECT * FROM login_student WHERE password='$pass' AND username='$user'");
 $rows = mysqli_num_rows($query);



if($rows == 1){
  // Redirecting to login session
 $_SESSION['user']= $user;
 $_SESSION['pass']= $pass;
 header("Location: index_student.php");
 }
 else
 {
 $error = "Username of Password is Invalid";
 }
 mysqli_close($conn); // Close connection
 }
}

?>
