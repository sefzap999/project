<?php
session_start();

if(!isset( $_SESSION['user'] ))
{
   //header("location:login.php");
	echo "<script>
		alert('กรุณาล้อคอินเพื่อเข้าสู่ระบบ');
    	location.href = 'login_admin.php';
	</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>แสดงข้อมูล</title>
	<link rel="stylesheet" href="styles.css" />
</head>
<body>
<form name="frmlist<?php echo $i;?>" method="post"></form>
<?php
	$host = "localhost";
	$username = "root";
	$password = "1234";
	$dbname = "project";
	$conn = mysqli_connect($host,$username,$password,$dbname);
	$conn->set_charset("utf8");
	$adminsql = "SELECT * FROM login_student WHERE student_id";
	$adminquery = mysqli_query($conn,$adminsql);
	$i = 0;

?>
	<table border="0" align="center" cellpadding="5" width="100%">
		<tr>
			<td align="left">	<b><font color="green">ชื่อผู้ใช้ :
				<?php
				echo $_SESSION["user"];
				?> </font></b>
			</td>
			<td align="right">
				<a href="logout_admin.php">
				<a href="logout_admin.php" class="gologout">
				<img src="https://estraha.com/images/logout.png" width="20" height="20">
				<font color="red">Logout</font></a>
			</td>
		</tr>
	</table>

	<table border="0" align="center" cellpadding="5" width="100%">
		<tr>
			<td align="center">
				<div class="datastudent"><u>ข้อมูลนักศึกษา</u></div>
			</td>
		</tr>
	</table>
	<table border="0" align="center" cellpadding="5" width="70%">
		<tr>
			<td>
				<div class="adddatastudent"><a href="add_student.php">เพิ่มข้อมูล</a>
				<img src="images/add.png" width="30" height="30"></div>
			</td>
		</tr>
		</tbody>
	</table>
	<table border="1" align="center" cellpadding="5" width="70%" cellspacing="0" style="border-color: #e9e9e9">
		<tr bgcolor="#e7e7e7">
			<th>ลำดับ</th>
			<th>ชื่อ-สกุล</th>
			<th>โทรศัพท์</th>
			<th>จังหวัด</th>
			<th>แก้ไข</th>
			<th>ลบ</th>
		</tr>
<?php
	while($result = mysqli_fetch_array($adminquery,MYSQLI_ASSOC)){
	$i++;
?>
		<tr align="center">
			<td><?php echo $i;?></td>
			<td><?php echo $result["student_Name"];?>  <?php echo $result["student_Lastname"];?></td>
			<td><?php echo $result["Telephone"];?></td>
			<td><?php echo $result["Province"];?></td>
			<td><center><a href="edit_student.php?student_id=<?php echo $result["student_id"];?>"><img src= images/edit.ico width=30 height=30 </a></center></td>
			<td><center><a href="del_student.php?student_id=<?php echo $result["student_id"];?>"><img src= images/delete.png width=30 height=30></a></center></td>
		</tr>

<?php
	}
?>
	</table>
</body>
</html>
