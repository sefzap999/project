<?php
include("loginserv.php"); // Include loginserv for checking username and password
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="logincss.css">
<title>Login</title>
</head>
<body style="height: 500px; margin-top: 40px; ">

<div class="headtittle">
	<img src="images/admin.png" width="80" height="80" border="0" alt="" align="absmiddle"> ผู้ดูแลระบบกรอกข้อมูลเพื่อเข้าสู่ระบบ
</div>
<hr>
<!-- login form-->
<div class="login">
<h1>LOGIN : Admin</h1>
<form action="" method="post" style="text-align:center;">
<input type="text" placeholder="Username" id="user" name="user"><br/><br/>
<input type="password" placeholder="Password" id="pass" name="pass"><br/><br/>
<input type="submit" value="Login" name="submit" style="margin-top: 25px;">
<input type="reset" value="Reset" name="reset" style="margin-top: 25px;>
<!-- Error -->
<span><font color="red"><?php echo $error; ?></font></span>
</form>
</div>
<p class="date">
		<img src="images/home.png" width="25" height="25" border="0" alt="" align="absmiddle">
		<a href="/fingerscan/index.html">หน้าแรก
	 </p>
</body>
</html>
