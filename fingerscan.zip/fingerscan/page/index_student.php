<?php
	ob_start();
	session_start();
	if(!$_SESSION["student_id"]){
		header("Location: ./login_student.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>ข้อมูลนักศึกษา</title>
	<link rel="stylesheet" href="styles.css" />
</head>
<body>
<center>
<form name="frmlist<?php echo $i;?>" method="post"></form>
<?php
	$host = "localhost";
	$username = "root";
	$password = "1234";
	$dbname = "project";
	$conn = mysqli_connect($host,$username,$password,$dbname);
	$conn->set_charset("utf8");
	$studentsql = "SELECT * FROM input_student WHERE student_id";
	$studentquery = mysqli_query($conn,$studentsql);
	$i = 0;

?>
	<table border="0" align="center" cellpadding="5" width="70%">
		<tr>
			<td align="left">
				<b>ชื่อผู้ใช้ :  <?php echo $_SESSION["Name"];?> <?php echo $_SESSION["Lastname"];?></b>
			</td>
			<td align="right">
				<a href="logout_student.php"><font color="red">ออกจากระบบ</font></a>
			</td>
		</tr>
	</table>
	<fieldset>
		<legend><h3>ข้อมูลนักศึกษา</h3></legend>
		<table>
			<tr>
				<?php 
					if($_SESSION["Gender"]=="ชาย"){
						echo"นาย";}
					elseif($_SESSION["Gender"]=="หญิง"){	
						echo"นางสาว";}
				?>
				<?php echo $_SESSION["Name"] . $_SESSION["Lastname"] ;?>
			</tr>
			<tr>
				<td align="right">รหัสนักศึกษา :</td>
				<td><?php echo $_SESSION["number"] ;?></td>
			</tr>
			<tr>
				<td align="right">สาขา :</td>
				<td>
					<?php 
					if($_SESSION["subagencies"]=="000994"){
						echo"วิศวกรรมคอมพิวเตอร์";}
					elseif($_SESSION["subagencies"]=="001017"){	
						echo"วิศวกรรมศาสตร์ หรือ เทคโนโลยี";}
					?>
				</td>
			</tr>
			<tr>
				<td align="right">คณะ :</td>
				<td><?php 
					if($_SESSION["agencies"]=="0088"){
						echo"คณะวิศวกรรมศาสตร์";}
					elseif($_SESSION["agencies"]=="00580"){	
						echo"คณะวิทยาศาสตร์เทคโนโลยีและการเกษตร";}
					elseif($_SESSION["agencies"]=="01063"){	
						echo"คณะวิทยาศาสตร์และเทคโนโลยีการเกษตร";}
					elseif($_SESSION["agencies"]=="01064"){	
						echo"คณะบริหารธุรกิจและศิลปศาสตร์";}
					elseif($_SESSION["agencies"]=="01065"){	
						echo"คณะศิลปกรรมและสถาปัตยกรรมศาสตร์";}
					elseif($_SESSION["agencies"]=="01104"){	
						echo"วิทยาลัยเทคโนโลยีและสหวิทยาการ";}
					?>

				</td>
			</tr>
			<tr>
				<td align="right">วัน-เดือน-ปี เกิด :</td>
				<td><?php echo $_SESSION["Birthdate"] ;?></td>
			</tr>
			<tr>
				<td align="right">อายุ :</td>
				<td><?php echo $_SESSION["Age"] ;?></td>
			</tr>
			<tr>
				<td align="right">ที่อยู่ :</td>
				<td><?php echo $_SESSION["Address"] ;?></td>
			</tr>
			<tr>
				<td align="right">จังหวัด :</td>
				<td><?php echo $_SESSION["Province"] ;?></td>
			</tr>
			<tr>
				<td align="right">รหัสไปรษณีย์ :</td>
				<td><?php echo $_SESSION["Zipcode"] ;?></td>
			</tr>
			<tr>
				<td align="right">โทรศัพท์ :</td>
				<td><?php echo $_SESSION["Telephone"] ;?></td>
			</tr>
			<tr>
				<td align="right">รายละเอียดอื่นๆ :</td>
				<td><?php echo $_SESSION["Description"];?></td>
			</tr>
		</table>
	</fieldset></center><br><br>

	<center><font color="blue"><b>เวลาที่นักศึกษาจะผ่านเกณฑ์การประเมินได้คือ 250 ชั่วโมง</b></font>
	<font color="red"><b>ขณะนี้ท่านได้จำนวนชั่วโมงของการเข้าร่วมกิจกรรมเท่ากับ 64 ชั่วโมง</b></font>

		<table width="90%" border="1" cellpadding="10">
		<tr>
		<th style="width: 0px;">รหัสกิจกรรม</th><th class="sorting" style="width: 0px;">ชื่อโครงการ/กิจกรรม</th><th class="sorting" style="width: 0px;">เทอม</th><th class="sorting" style="width: 0px;">วันที่ทำกิจกรรม</th><th class="sorting" style="width: 0px;">ประเภทกิจกรรม/จำนวนชั่วโมง</th>		</tr>

		<tr>
				<td>91010002</td><td>กิจกรรมสร้างจิตสาธารณะ</td><td>1/2558</td><td>06/04/2558 ถึง 06/05/2558 <br>เวลา 8.00 - 12.00</td><td>กิจกรรมบังคับ1 / 6ชั่วโมง</td></tr><tr>
				<td>91010002</td><td>กิจกรรมสร้างจิตสาธารณะ</td><td>1/2558</td><td>01/06/2558 ถึง 01/06/2558 <br>เวลา 8.00 - 9.00 </td><td>กิจกรรมบังคับ1 / 6ชั่วโมง</td></tr><tr>
				<td>91010002</td><td>กิจกรรมสร้างจิตสาธารณะ</td><td>1/2558</td><td>02/12/2558 ถึง 02/01/2559 <br>เวลา 8.00 - 19.00</td><td>กิจกรรมบังคับ1 / 6ชั่วโมง</td></tr><tr>
		</tr>
		</table>

</center>
</table>
</body>
</html>
