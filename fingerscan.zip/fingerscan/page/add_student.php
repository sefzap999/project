<?php
	ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>เพิ่มข้อมูล</title>
	<link rel="stylesheet" href="styles.css" />
</head>
<body>
<center>
<form name="addstudent" method="POST" >
	<div class="datastudent"> เพิ่มข้อมูล </div>
		<fieldset style="width: 60%">
			<legend>ข้อมูล</legend>
			<table cellpadding="3">
				<tr>
					<td>
						ชื่อ :
					</td>
					<td>
						<input type="text" name="txtname" class="student">
					</td>
				</tr>
				<tr>
					<td>
						นามสกุล :
					</td>
					<td>
						<input type="text" name="txtlastname" class="student">
					</td>
				</tr>
				<tr>
					<td>
						รหัสนักศึกษา :
					</td>
					<td>
						<input type="text" name="txtnumber" class="student" maxlength="13">
					</td>
				</tr>
				<tr>
					<td>
						คณะวิชา  : 
					</td>
					<td><select name="selectagencies">
	                    <option value=""></option>
	                    <option value="00088">คณะวิศวกรรมศาสตร์</option>
	                    <option value="00580">คณะวิทยาศาสตร์เทคโนโลยีและการเกษตร</option>
	                    <option value="01063">คณะวิทยาศาสตร์และเทคโนโลยีการเกษตร</option>
	                    <option value="01064">คณะบริหารธุรกิจและศิลปศาสตร์</option>
	                    <option value="01065">คณะศิลปกรรมและสถาปัตยกรรมศาสตร์</option>
	                    <option value="01104">วิทยาลัยเทคโนโลยีและสหวิทยาการ</option>
                    </select>
                	</td>
                </tr>
                <tr>
                	<td>
            			สาขาวิชา  :
            		</td>
            		<td>
            			<select name="selectsubagencies">
                        <option value=""></option>
						<option value="000000">ไม่ระบุ (ในกรณีที่นักศึกษาเข้าใหม่ยังไม่ได้เลือกสาขาวิชา)</option>
						<option value="000024">การจัดการ</option>
						<option value="000064">การจัดการธุรกิจระหว่างประเทศ</option>
						<option value="000101">การตลาด</option>
						<option value="000107">การท่องเที่ยว</option>
						<option value="000109">การท่องเที่ยวและโรงแรม</option>
						<option value="000370">คหกรรมศาสตร์</option>
						<option value="000452">ช่างกลโรงงาน</option>
						<option value="000453">ช่างก่อสร้าง</option>
						<option value="000457">ช่างอิเล็กทรอนิกส์</option>
						<option value="000467">ช่างไฟฟ้า</option>
						<option value="000577">บริหารธุรกิจ</option>
						<option value="000690">พัฒนาผลิตภัณฑ์อุตสาหกรรมเกษตร</option>
						<option value="000758">ภาษาอังกฤษธุรกิจ</option>
						<option value="000766">ภาษาอังกฤษเพื่อการสื่อสารสากล</option>
						<option value="000813">ระบบสารสนเทศคอมพิวเตอร์</option>
						<option value="000886">วิทยาการคอมพิวเตอร์</option>
						<option value="000965">วิทยาศาสตร์และเทคโนโลยีการอาหาร</option>
						<option value="000978">วิศวกรรมกระบวนการอาหาร</option>
						<option value="000994">วิศวกรรมคอมพิวเตอร์</option>
						<option value="001017">วิศวกรรมศาสตร์ หรือ เทคโนโลยี</option>
						<option value="001023">วิศวกรรมสิ่งแวดล้อม</option>
						<option value="001025">วิศวกรรมอาหาร</option>
						<option value="001026">วิศวกรรมอิเล็กทรอนิกส์</option>
						<option value="001029">วิศวกรรมอิเล็กทรอนิกส์และโทรคมนาคม</option>
						<option value="001032">วิศวกรรมอุตสาหการ</option>
						<option value="001033">วิศวกรรมเกษตร</option>
						<option value="001037">วิศวกรรมเครื่องกล</option>
						<option value="001040">วิศวกรรมเครื่องจักรกลเกษตร</option>
						<option value="001049">วิศวกรรมเหมืองแร่</option>
						<option value="001057">วิศวกรรมโยธา</option>
						<option value="001062">วิศวกรรมไฟฟ้า</option>
						<option value="001119">สถาปัตยกรรม</option>
						<option value="001120">สถาปัตยกรรมภายใน</option>
						<option value="001121">สถาปัตยกรรมศาสตร์</option>
						<option value="001178">สิ่งทอ</option>
						<option value="001222">ออกแบบบรรจุภัณฑ์</option>
						<option value="001229">ออกแบบสิ่งทอ</option>
						<option value="001230">ออกแบบอุตสาหกรรม</option>
						<option value="001310">เครื่องจักรกลเกษตร</option>
						<option value="001319">เซรามิกส์</option>
						<option value="001345">เทคโนโลยีการผลิตสัตว์</option>
						<option value="001350">เทคโนโลยีการพิมพ์</option>
						<option value="001363">เทคโนโลยีการอาหาร</option>
						<option value="001365">เทคโนโลยีการเกษตร</option>
						<option value="001375">เทคโนโลยีคอมพิวเตอร์</option>
						<option value="001379">เทคโนโลยีชีวภาพ</option>
						<option value="001403">เทคโนโลยีภูมิทัศน์</option>
						<option value="001422">เทคโนโลยีสถาปัตยกรรม</option>
						<option value="001423">เทคโนโลยีสารสนเทศ</option>
						<option value="001442">เทคโนโลยีอาหาร</option>
						<option value="001450">เทคโนโลยีอุตสาหกรรม</option>
						<option value="001455">เทคโนโลยีอุตสาหการ</option>
						<option value="001457">เทคโนโลยีเครื่องกล</option>
						<option value="001458">เทคโนโลยีเครื่องจักรกลเกษตร</option>
						<option value="001461">เทคโนโลยีเซรามิก</option>
						<option value="001470">เทคโนโลยีเหมืองแร่</option>
						<option value="001478">เทคโนโลยีโทรคมนาคม</option>
						<option value="001481">เทคโนโลยีไฟฟ้า</option>
						<option value="001581">โยธา</option>
						<option value="001613">การคอมพิวเตอร์ธุรกิจ</option>
						<option value="001734">วิศวกรรมโลจิสติกส์</option>
						<option value="001774">เทคนิคอุตสาหกรรม</option>
						<option value="001776">เทคนิคคอมพิวเตอร์</option>
						<option value="002107">ช่างโยธา</option>
						<option value="002256">ช่างกลเกษตร</option>
						<option value="002260">ช่างจักรกลหนัก</option>
						<option value="002266">ช่างโลหะ</option>
						<option value="002309">ระบบสารสนเทศทางคอมพิวเตอร์</option>
						<option value="002339">อิเล็กทรอนิกส์สื่อสาร</option>
						<option value="002816">บัญชีบริหาร</option>
						<option value="003076">อิเล็กทรอนิกส์</option>
						<option value="003122">การท่องเที่ยวและการโรงแรม</option>
						<option value="003292">วิศวกรรมแม่พิมพ์</option>
						<option value="003536">ออกแบบสื่อสาร</option>
						<option value="003571">ช่างยนต์</option>
						<option value="P01991">บธ.บ.(การจัดการ,การตลาด,ระบบสารสนเทศ), บช.บ.การบัญชี</option>
						</select></td></tr>
				</tr>
				<tr>
					<td>
						เพศ :
					</td>
					<td>
						<input type="radio" name="gender" value="ชาย">ชาย
						<input type="radio" name="gender" value="หญิง">หญิง
					</td>
				</tr>
				<tr>
					<td>
						วัน-เดือน-ปี เกิด :
					</td>
					<td>
						<select class="date" name="selectdate" id="date" style="margin: 0px"><?php for($i=1; $i<=31; $i++) {?>
                      		<option value="<?php echo $i?>"><?php echo $i?></option>
                      		<?php }?>
                    	</select>
                    	<select class="month" name="selectmonth" id="month">
                      		<?php $month = array("มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");?>
                      		<?php for($i=0; $i<sizeof($month); $i++) {?>
                      		<option value="<?php echo $month[$i]?>">
                      		<?php echo $month[$i]?></option>
                      		<?php }?>
                    	</select>
                    	<select class="year" name="selectyear" id="year">
                      		<?php for($i=0; $i<=50; $i++) {?>
                      		<option value="<?php echo date("Y")-$i+543?>"><?php echo date("Y")-$i+543?></option>
                      		<?php }?>
                    	</select>
					</td>
				</tr>
				<tr>
					<td>
						อายุ :
					</td>
					<td>
						<input type="text" name="txtage" class="student" value="">
					</td>
				</tr>
				<tr>
					<td>
						ที่อยู่ :
					</td>
					<td>
						<input type="text" name="txtaddress" class="student">
					</td>
				</tr>
				<tr>
					<td>
						จังหวัด :
					</td>
					<td>
						<select name="selectprovince" class="month">
							<option value=""></option>
							<option value="เชียงราย">เชียงราย</option>
							<option value="เชียงใหม่">เชียงใหม่</option>
                      		<option value="น่าน">น่าน</option>
						    <option value="พะเยา">พะเยา</option>
						    <option value="แพร่">แพร่</option>
						    <option value="แม่ฮ่องสอน">แม่ฮ่องสอน</option>
						    <option value="ลำปาง">ลำปาง</option>
						    <option value="ลำพูน">ลำพูน</option>
						    <option value="อุตรดิตถ์">อุตรดิตถ์</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						รหัสไปรษณีย์ :
					</td>
					<td>
						<input type="text" name="txtzipcode" class="student" maxlength="6">
					</td>
				</tr>
				<tr>
					<td>
						โทรศัพท์ :
					</td>
					<td>
						<input type="text" name="txtphone" class="student" maxlength="10">
					</td>
				</tr>
				<tr>
					<td>
						รายละเอียดอื่นๆ :
					</td>
					<td>
						<textarea name="txtdetail" cols="23" rows="5" class="student"></textarea>
					</td>
				</tr>
			</table>
			<fieldset class="user">
				<legend>Account</legend>
				<table>
					<tr>
						<td>
							Username :
						</td>
						<td>
							<input type="text" name="txtusername" class="student" required="required">
						</td>
					</tr>
					<tr>
						<td>
							Password :
						</td>
						<td>
							<input type="password" name="txtpassword" class="student" required="required">
						</td>
					</tr>
				</table>
			</fieldset>
		</fieldset>
		<br>
		<input type="submit" name="submit" value="เพิ่มข้อมูล">
		<input type="button" name="submit" value="ยกเลิก" onclick="window.location='index_admin.php' ">
	</div>
</form>
<?php

	ini_set('display_errors', 1);
	error_reporting(~0);

	$host = "localhost";
	$username = "root";
	$password = "1234";
	$dbname = "project";
	$conn = mysqli_connect($host,$username,$password,$dbname);

	if(isset($_POST["submit"])){
		$date = $_POST["selectdate"]." ".$_POST["selectmonth"]." ".$_POST["selectyear"];

		$cussql = "SELECT * FROM login_student WHERE Username = '".trim($_POST['txtusername'])."' ";
		$cusquery = mysqli_query($conn,$cussql);
		$cusresult = mysqli_fetch_array($cusquery,MYSQLI_ASSOC);
		if($cusresult["username"] == $_POST["txtusername"]){
			ob_clean();
			echo "Username นี้มีอยู่แล้ว";
			echo "<meta http-equiv='refresh' content='2;url=add_student.php'>";
		}else{
			$conn->set_charset("utf8");
			$sql = "INSERT INTO login_student (student_Name, student_Lastname ,student_number ,agencies ,subagencies ,Gender, Birthdate, Age,Address, Province, 	Zipcode, Telephone, student_Description, username, password)
				VALUES ('".$_POST["txtname"]."',
						'".$_POST["txtlastname"]."',
						'".$_POST["txtnumber"]."',
						'".$_POST["selectagencies"]."',
						'".$_POST["selectsubagencies"]."',
						'".$_POST["gender"]."',
						'".$date."',
						'".$_POST["txtage"]."',
						'".$_POST["txtaddress"]."',
						'".$_POST["selectprovince"]."',
						'".$_POST["txtzipcode"]."',
						'".$_POST["txtphone"]."',
						'".$_POST["txtdetail"]."',
						'".$_POST["txtusername"]."',
						'".$_POST["txtpassword"]."'
						)";
			$query = mysqli_query($conn,$sql);

			if($query) {
				ob_clean();
				echo "Record add successfully";
				echo "<meta http-equiv='refresh' content='2;url=index_admin.php'>";

			}else{
				ob_clean();
				echo "Record add Fail";
				echo "<meta http-equiv='refresh' content='2;url=add_student.php'>";

			}
		}
	}
	mysqli_close($conn);
?>
</center>
</body>
</html>
